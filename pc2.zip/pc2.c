#include <stdio.h>  
#include <string.h> 
#include <ctype.h> 
#include <math.h>   

 
int main() {


  printf("Introduce un numero hexadecimal:\n");
         
  
  return 0;
}